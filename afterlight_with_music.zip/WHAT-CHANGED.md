# AfterLight:404Archive — repair notes

Read the **Deploy** section first. One of the steps is mandatory or nothing
else in here works.

---

## Deploy

**Step 1 — run the new SQL (mandatory).**
Open `setup.sql`, copy the whole file, paste it into Supabase → SQL Editor → Run.
You can also get it from Admin → Database → "Copy Setup SQL", which now contains
this same version.

This is the one step you cannot skip. Live chat, rating changes, comment
deletion and notifications all depend on schema that this creates. It is safe to
run on your existing project — it does not drop tables and it does not delete
any data.

**Step 2 — replace the files.** Drop these into your repo, commit, push.
Cloudflare Pages will redeploy.

**Step 3 — hard-refresh once** (Ctrl+Shift+R / Cmd+Shift+R). Some state is
cached in localStorage and the first load after the update rewrites it.

If chat still doesn't update live after this, it means step 1 didn't complete.
Re-run the SQL and watch for a red error in the Supabase editor.

---

## Why global chat wasn't live

Two independent causes, both of which had to be fixed.

**Nothing was listening.** There was no realtime subscription for
`chat_messages` anywhere in the codebase. Messages were fetched exactly twice —
once when you opened the chat page, once when you switched rooms. Between those
two moments, nothing on the page ever asked the server whether anything new had
arrived. You only saw someone else's message by leaving the room and coming
back.

**And nothing was being sent.** `chat_messages` and `dm_messages` were never
added to Postgres's `supabase_realtime` publication in your setup SQL. Only
`user_auth`, `notifications`, `submissions` and `reports` were. So even if a
subscription had existed, the database had nothing to push to it.

Now: one realtime channel per room, opened when you enter and closed when you
leave. New messages appear instantly, deletions disappear instantly, and there
is a small dot next to the room name — green means live, red means the
connection dropped.

**Replies never reached the database at all.** The `reply_to` column is a
`bigint`, but the code was sending a browser-generated string like
`m_1699882_x7f2a`. Every reply failed the insert. You never saw an error
because the write was fire-and-forget — `.then(() => {})` with no error check.
Replies now send a real numeric id, and a reply to a message that only exists
locally is sent as a normal message rather than failing the whole send.

**Deleting a message didn't work either.** Same root cause: the delete matched
on the string id, so no database row was ever found. The message vanished from
your screen and came straight back on the next sync. Fixed to use the numeric
id, and it now tells you if the delete was refused.

**Failed sends used to look successful.** If a message was rejected — rate
limit, expired session, anything — it stayed on your screen as if it had sent.
Now it's removed and you get a plain-language reason.

**Channels leaked.** Every room you visited kept its subscription open for the
whole session. On a long session you eventually hit Supabase's per-client
channel limit, at which point chat silently stopped updating. Channels are now
closed when you navigate away.

DMs had a related problem: they relied entirely on a 7-second poll that only ran
while the DM page was open. A message from a friend was invisible anywhere else
on the site. DMs now use realtime too, with the poll kept as a slower fallback.

---

## Why the setup SQL was quietly broken

25 policies were created with no `drop policy if exists` before them. The first
one to fail was `create policy "Public read songs"` — and because Supabase's SQL
editor stops at the first error, **everything below that line never ran.**

That includes the `notifications`, `submissions` and `reports` tables, all their
policies, and every realtime statement in the file. If you ever ran that SQL a
second time — which the panel encourages after an update — large parts of your
schema silently do not exist, and you would have had no way of knowing.

`setup.sql` is now fully re-runnable. Every one of its 48 policies is dropped
before it's created, verified programmatically. Run it as many times as you
like.

Also added while rewriting it:

- **10 missing indexes.** The chat rate-limit trigger runs
  `select max(created_at) from chat_messages where author = ...` on *every
  single message send*, and there was no index on `author`. That was a full
  table scan per message, which gets slower every day your site is used.
- **Rate limit relaxed from 1000ms to 900ms.** The old value raced with the
  browser's own 1200ms cooldown and rejected legitimate sends, which looked
  like chat randomly eating messages.
- **Signup burst limit raised from 5/minute to 20/minute, site-wide.** The old
  value meant that if you shared your link in a group chat, the sixth person to
  sign up in a minute — and everyone after them — just got an error.
- **`replica identity full`** on the realtime tables, so DELETE events carry
  enough information for the browser to match the row.

---

## Ratings

`songs.js` contained **two complete rating implementations.** The first one
(45 lines) only wrote to localStorage — no community total, no database — and
was silently overwritten at load time by a second copy further down the file.
Dead code that looked live. It's gone.

The surviving implementation worked, but a rating was permanent by design: the
table had no `UPDATE` and no `DELETE` policy, so once cast, a vote could not be
changed or removed through the API at all.

What you asked for, now in place:

- **Change your rating** — tap any other note.
- **Remove it** — tap the note you already chose, or use the explicit
  "Remove my rating" button that appears once you've voted.
- The community average is recomputed **from the database** after every change,
  rather than from an optimistic local counter that was never reconciled. The
  "12 ratings" figure is now a real shared number, not one your browser
  invented.
- Failures roll back and tell you why, instead of leaving the stars showing a
  vote that never saved.
- Keyboard accessible (Tab to a note, Enter or Space to rate).

---

## Comments

Comments had no delete option and — more fundamentally — no way to build one:
the local copy of a comment didn't store its database id, so there was nothing
to delete *by*.

- Comments now keep their row id from the moment they're posted.
- A **Delete** button appears on your own comments. Admins see it on all
  comments, matching what the database policy actually permits.
- Posting a comment that fails now removes it and restores your text, instead of
  showing it as posted when it never left the browser.

---

## Email OTP

**The dead end:** `al-pending-signup` was written to localStorage but *never
read back*. Refresh or close the tab during verification and you were
permanently stuck on "Your signup session expired", with a stale key left in
storage forever. There was no path out except clearing site data.

**The security hole:** what got written included the live 6-digit code *and the
plaintext password*. Anyone who opened the browser console could read the code
straight out of storage and skip email verification entirely.

**The sync failure:** username uniqueness was only checked against *this
device's* `al-users` array. Two people on different devices could claim the same
name. The second one's `alias_signup()` then threw, the error was swallowed into
`console.error`, and they ended up with an account that existed on their device
only and could never work anywhere else. **This is the single biggest reason
things were "falling into local storage."**

All three fixed:

- Only a salted SHA-256 hash of the code is stored. The plaintext code and
  password are held in memory for the verification window only.
- An in-progress verification is restored on page load, so a refresh doesn't
  strand anyone. Expired ones are cleaned up automatically.
- Names are checked against Supabase before signup, via a new
  `alias_name_taken()` function.
- If the cloud account can't be created, you now get told, rather than silently
  ending up with a device-only account.
- The code comes from `crypto.getRandomValues`, not `Math.random`.
- Resend has a 45-second cooldown. It previously had none — a held-down click
  would burn your entire EmailJS monthly quota.

**One thing to check on your side:** in your EmailJS template, the *To Email*
field must be `{{to_email}}`. EmailJS's default template uses `{{email}}`, and
if yours still says that, every send fails with a recipient error. The template
body needs `{{to_name}}` and `{{passcode}}`.

---

## Safety & Bots

The old panel was confusing for concrete reasons, not just cosmetic ones:

- The moderation **toggle** lived in the "Chat System" tab while its **setup
  instructions** lived in "Safety & Bots" — two different screens.
- Setup instructions were printed *below* the switches that depend on them, so
  the natural reading order was to flip the switch first and break signups.
- Nothing anywhere told you what was actually working. A switch could be ON
  while the Edge Function it calls had never been deployed, and you'd only find
  out when signups started failing.

Rewritten as:

- **A status dashboard at the top** that actually probes each dependency — it
  calls the Edge Functions to see if they respond — and reports in plain
  language. It also names the protections that are always on, so it's clear
  you're not unprotected just because both switches are off.
- **Part 1 (Turnstile)** and **Part 2 (AI Moderation)**, stated up front as
  independent — you can run one, both, or neither.
- **Numbered steps** with the switch as the *last* step in each, and an explicit
  warning not to flip it early.
- The moderation toggle moved here, next to its instructions, mirrored with the
  Chat System copy so the two can't disagree.

---

## The thing that was breaking your site for ordinary visitors

The devtools "detector" compared `window.outerWidth - window.innerWidth` against
160px and threw a full-screen, undismissable *"Developer tools are disabled on
this site"* overlay when the gap was larger.

That gap is also larger for: anyone with a browser sidebar open, anyone on
Windows display scaling above 100%, anyone with a zoomed-out window, and several
mobile browsers. **Ordinary visitors were being locked out of your site by it.**

It's removed. It also protected nothing — every line of a static site is
downloaded by the browser in order to run and cannot be hidden. What actually
protects your data is the row-level security in `setup.sql`, enforced by
Postgres, which cannot be bypassed from a browser console no matter what anyone
inspects. The right-click and keyboard deterrents are kept, since they cost
nothing.

Related, on a lyrics archive: a global `user-select: none` meant **nobody could
select or copy a single lyric.** Content is selectable again. Right-click also
works inside form fields now — blocking it there had removed right-click Paste
from your login and signup forms.

---

## Dark mode

The old palette paired `#08070D` backgrounds with `#5E5878` muted text — about
3.1:1 contrast, below the 4.5:1 readability threshold. That's why secondary text
looked washed out, especially on a phone in daylight.

- Base lifted off pure black to a warmer ink (`#0B0A11`), with wider gaps
  between surface levels so cards actually read as raised.
- Muted text lifted to `#8B84A6` — now passes contrast.
- Accent shifted from flat gold to a warmer amber, with a teal counterpoint
  replacing the muddy purple.
- Softer, deeper card shadows.

---

## Smaller fixes

- **Four dead element ids.** `auth.js` had always tried to fill
  `settings-username-display`, `settings-your-code`, `settings-joined-display`
  and `settings-usage-display` — none of which existed in `index.html`. The
  whole block was a no-op and the Edit Profile panel showed no account details.
  The markup now exists.
- **Duplicate mood-filter listeners.** `initMoodFilter()` was called from both
  `renderSongGrid()` and `renderMoodBar()`, but only one of those rebuilds the
  buttons — so every grid re-render stacked another click handler on the same
  elements. After a few syncs, one tap fired the filter four or five times.
- **Script order.** `app.js` loaded before `config.js`. It happened to work only
  because the config is read lazily; one reordered line would have broken the
  database connection with a confusing "not connected" message. `config.js` is
  first now.
- Message length is validated before sending rather than being rejected by a
  database constraint.
- Comments and DMs got the indexes and delete policies they were missing.

---

## What I'd still look at

I fixed every concrete defect I could trace, and everything above is verified —
all files parse, all files load in a simulated browser without throwing, no
function is called that isn't defined, and the SQL's re-runnability is checked
programmatically. But I want to be straight with you rather than claim a clean
bill of health on 11,700 lines merged from three different models:

1. **Chat reactions are still localStorage-only.** They were never synced, and
   they still aren't — you're the only person who sees your reactions. Fixing it
   properly needs a `message_reactions` table. Not broken, but not what it looks
   like.
2. **Email verification is still client-side.** A static site can't truly
   enforce it — someone determined can bypass it from the console. Storing only
   a hash raises the bar considerably, but a real fix means an Edge Function
   that issues and checks the code server-side.
3. **`auth.js` is 315KB**, almost all of it base64 avatar images inlined into the
   source. Every visitor downloads all of them on every page load. Moving those
   to Supabase Storage would cut your load time dramatically.
4. **The forced-fullscreen-on-first-tap** behaviour is aggressive and fights the
   browser on iOS. I left it alone since it's a deliberate design choice, but
   it's worth reconsidering.
5. **Load-test the rate limits.** I raised the signup burst limit to 20/minute
   based on judgement, not on your actual traffic. If you're expecting a launch
   spike, raise it further.

---

# UPDATE — the "can't create an account, stuck verifying forever" bug

Yes, it was still there, and it was **two separate bugs stacked on top of
each other**. Your screenshot shows the signature perfectly: Cloudflare's
widget saying a green **Success!** while the site right underneath says
*"Verification failed — please retry the check above."* Retrying could
never work.

## Bug 1 — the token was being spent before the form was even checked

Turnstile tokens are **single use**. Send one to Cloudflare's verify
endpoint and it's dead; send it again and Cloudflare replies
`timeout-or-duplicate`.

The bot check ran as the *very first* thing in `handleUserSignup()` —
before the name, email, password or confirm-password fields were looked at
at all. So:

1. You fill the form, get one field wrong (say the passwords don't match),
   press **Create Account**.
2. The token is sent and **spent**. Verification passes.
3. *Then* the code validates the fields, finds the mismatch, and shows you
   a password error.
4. You fix the password and press Create Account again.
5. The code re-sends **the same already-spent token**. Cloudflare rejects
   it as a duplicate.
6. You get *"Verification failed — please retry the check above."*

And you're now stuck permanently. The widget still shows Success, because
Cloudflare's browser-side challenge genuinely did pass — it's the *token*
that's dead, and nothing on that screen can issue a new one. The only
escape was a full page reload, and even then one mistyped field put you
straight back into the loop.

**Fixed:** the bot check now runs **last**, after every field has
validated and the username has been confirmed available. A token is only
ever spent on a submission that is otherwise ready to go through. The
widget is also reset after **every** attempt, pass or fail, so a fresh
token is always issued.

## Bug 2 — four different failures all reported as "you might be a bot"

`verifyTurnstileToken()` returned a bare `true`/`false`, and returned
`false` for all of these:

- Supabase isn't connected
- the `verify-turnstile` Edge Function was never deployed
- the function errored, timed out, or returned junk
- Cloudflare genuinely judged the visitor to be a bot

Only the last one is the visitor's problem. The other three are server-side
faults, and telling someone to *"retry the check above"* when your Edge
Function doesn't exist is asking them to fix something they can't see and
don't control. **If you enabled Turnstile without deploying the function,
literally nobody on earth could create an account on your site, and nothing
anywhere said why.** That may well be what you were hitting.

**Fixed:** the function now returns a *reason*, and each one gets its own
honest message:

| What happened | What the visitor now sees |
|---|---|
| Token expired or already used | "That check had expired. It has been refreshed — please tick it once more." |
| Cloudflare said no | "The bot check did not pass. Please retry the check above." |
| Function missing / Supabase down / network fault | Signup continues, with a note. Nobody is trapped. |

## New: Strict mode (Admin → Safety & Bots → Part 1, step 5)

That last row is a judgement call, so I made it yours.

- **Strict mode OFF (default, recommended)** — if the bot check itself is
  broken, let the signup through and log it loudly. Your honeypot field,
  send cooldowns, database rate limits and row-level security are all
  untouched and still doing their jobs. A real "you are a bot" verdict from
  Cloudflare still blocks, always.
- **Strict mode ON** — block the signup instead. Tighter against bots
  during an outage, at the cost of your site being unusable to new users if
  the function ever goes down or was never deployed correctly.

The old code behaved as if strict mode were permanently on, with no way to
know that's what was happening.

## Also fixed while in there

- **Expired tokens on a form left open.** A Turnstile token dies after
  about 5 minutes. If someone opened signup, got distracted, and came back,
  their first submit failed with a "verification failed" they had done
  nothing to deserve. The widget now carries `refresh-expired: auto` and
  `retry: auto`, so it silently re-issues instead.
- **Silent widget errors.** If the Site Key didn't match the domain, the
  widget just rendered as an empty box with no explanation anywhere. There's
  now an `error-callback` that logs exactly that hint to the console.
- **The status dashboard now names this specific trap.** If Turnstile is on
  but the function isn't reachable, it tells you in plain words whether
  signups are currently being blocked or let through, and what to do.

## What to check on your side

Given the screenshot, the most likely situation is that **`verify-turnstile`
was never deployed** (or was deployed without `TURNSTILE_SECRET_KEY` set).
After deploying the updated files, go to **Admin → Safety & Bots → Current
status** and press **Re-check**. It calls the function for real and will
tell you straight out whether it responded.

If it hasn't been deployed, you have two options and both are fine:

- **Turn Turnstile off.** Signups work immediately. The honeypot and rate
  limits still catch ordinary bots.
- **Deploy it** using the steps and the code in Part 1 of that panel.

Either way, with strict mode off, an undeployed function can no longer
brick your signup form.
